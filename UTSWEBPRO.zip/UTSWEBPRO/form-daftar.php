<!DOCTYPE html>
<html>
<head>
    <title>Formulir Pendaftaran Mahasiswa</title>
</head>

<body>
<style>
        body {
            background-color:#F0F8FF;
        }
        p {
            border: 1px solid;
            padding: 10px;
        }

        p {
            border-collapse: collapse;
            width: 100%;
        }
    </style>
    <header><center>
        <h3>Formulir Pendaftaran Mahasiswa Baru</h3>
    </header>

    <form action="proses-pendaftaran.php" method="POST">
        <p>
            <label for="nama">Nama: </label>
            <input type="text" name="nama" placeholder="nama lengkap" />
        </p>
        <p>
            <label for="alamat">Alamat: </label>
            <textarea name="alamat"></textarea>
        </p>
        <p>
            <label for="jenis_kelamin">Jenis Kelamin: </label>
            <label><input type="radio" name="jenis_kelamin" value="laki-laki"> Laki-laki</label>
            <label><input type="radio" name="jenis_kelamin" value="perempuan"> Perempuan</label>
        </p>
        <p>
            <label for="agama">Agama: </label>
            <select name="agama">
                <option>Islam</option>
                <option>Kristen</option>
                <option>Hindu</option>
                <option>Budha</option>
            </select>
        </p>
        <p>
            <label for="sekolah_asal">Sekolah Asal: </label>
            <input type="text" name="sekolah_asal" placeholder="nama sekolah" />
        </p>           
        <input type="submit" value="Daftar" name="daftar" />
        <a href="index.php">back menu utama</a>
    </form>
</center>
    </body>
</html>
