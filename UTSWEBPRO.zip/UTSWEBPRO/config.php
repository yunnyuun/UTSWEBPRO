<?php

$server = "localhost";
$user = "root";
$password = "";
$dbname = "pendaftaran";

$db = mysqli_connect($server, $user, $password, $dbname);

if (!$db) {
	die("Gagal terhubung dengan database: " . mysqli_connect_error());
}

function getAllData($db)
{
    $sql = "SELECT * FROM calon_siswa";
    $result = mysqli_query($db, $sql);

    $siswa = [];

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $siswa[] = $row;
        }
    }

    return $siswa;
}
function findPendaftaranByID($db, $id) 
{
    $sql = "SELECT * FROM calon_siswa WHERE id = $id LIMIT 1";
    $result = mysqli_query($db, $sql);


    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            return $row;
        }
    }

    return null;
}

function pendidikanBaru($db, $siswa)
{
    $sql = "INSERT INTO calon_siswa
    (nama, alamat, jenis_kelamin, agama, sekolah_asal, created_at, updated_at)
    VALUES (
        {$siswa['nama']}, 
        '{$siswa['alamat']}', 
        '{$siswa['jenis_kelamin']}', 
        '{$siswa['agama']}', 
        '{$siswa['sekolah_asal']}', 
        NOW(), 
        NOW()
    );";

    if (mysqli_query($db, $sql)) {
        return mysqli_insert_id($db);
    }

    return null;
}


