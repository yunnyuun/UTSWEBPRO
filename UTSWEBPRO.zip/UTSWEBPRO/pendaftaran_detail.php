<?php
require_once "config.php";

$id = $_GET['id'];

$d = findPendaftaranByID($db, $id);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calon Siswa</title>
</head>

<body>
    <h1>Detail Pendaftaran Mahasiswa Baru</h1>

    <a href="/list-siswa.php">Kembali ke daftar Camaba</a>

    <br>
    <br>

    <p>Nama : <?= $d['nama'] ?></p>
    <p>Alamat : <?= $d['alamat'] ?></p>
    <p>Jenis Kelamin : <?= $d['jenis_kelamin'] ?></p>
    <p>Agama : <?= $d['agama'] ?></p>
    <p>Sekolah Asal : <?= $d['sekolah_asal'] ?></p>
    <p>Created At : <?= $d['created_at'] ?></p>
    <p>Updated At : <?= $d['updated_at'] ?></p>

</body>


</html>

<?php
mysqli_close($db);
?>